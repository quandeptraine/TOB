#!/bin/sh
set -eu

APP="${1:-}"
if [ -z "$APP" ] || [ ! -d "$APP" ]; then
  echo "Usage: $0 /path/to/CorsixTH.app" >&2
  exit 2
fi

rm -rf Payload CorsixTH-iOS.ipa
mkdir Payload
cp -R "$APP" Payload/CorsixTH.app
zip -qr CorsixTH-iOS.ipa Payload
rm -rf Payload

echo "Created CorsixTH-iOS.ipa"
