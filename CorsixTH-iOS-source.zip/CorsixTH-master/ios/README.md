# CorsixTH iOS build

This tree adds an iOS device target without signing. The generated app is intended to be signed by the owner on macOS/Xcode.

## Requirements

- macOS with Xcode and command-line tools
- CMake 3.24+
- vcpkg installed and `VCPKG_ROOT` exported
- An `arm64-ios` vcpkg triplet

## Configure + build

```sh
cmake --preset ios-device
cmake --build build/ios-device --config Release --target CorsixTH
```

The resulting unsigned app is under the Xcode build products directory. Open the generated Xcode project if you want to select a signing team/device and Archive/Build for your own signing workflow.

## IPA

After signing the app, package it with:

```sh
mkdir -p Payload
cp -R path/to/CorsixTH.app Payload/
zip -r CorsixTH-iOS.ipa Payload
```

The project intentionally does not include a certificate, provisioning profile, or Apple account configuration.

## Helper scripts

- `./ios/build-ios.sh` configures and builds the unsigned iOS target.
- `./ios/build-ipa.sh /path/to/CorsixTH.app` packages an already-signed `.app` into `CorsixTH-iOS.ipa`.

## GitHub Actions

For a GitHub-hosted macOS build that produces an unsigned IPA artifact, see:

- `.github/workflows/build-ios-ipa.yml`
- `ios/GITHUB-ACTIONS.md`

The workflow can be started manually from the GitHub Actions tab and does not require your Apple signing credentials.
