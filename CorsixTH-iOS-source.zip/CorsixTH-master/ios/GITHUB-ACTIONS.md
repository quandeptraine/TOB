# GitHub Actions: build IPA

This repository contains a workflow at `.github/workflows/build-ios-ipa.yml`.
It builds an **unsigned** iOS device app on a GitHub-hosted macOS runner and packages it as an IPA.

## How to use

1. Create a GitHub repository.
2. Upload/push this source tree to the repository.
3. Open **Actions**.
4. Select **Build CorsixTH iOS IPA**.
5. Click **Run workflow**.
6. Wait for the macOS build to finish.
7. Open the completed workflow run.
8. Download the artifact named **CorsixTH-iOS-unsigned-ipa**.

The downloaded artifact contains:

```text
CorsixTH-iOS-unsigned.ipa
```

This workflow deliberately does not use an Apple signing certificate or provisioning profile. Sign the IPA yourself with your preferred sideloading/signing workflow.

## Important

The workflow builds from source and downloads C/C++ dependencies through vcpkg. The first run can take a while.

The iOS preset disables movies, update checking and MIDI because those desktop-oriented dependencies are not required for the iOS build.

## iOS vcpkg fix

The iOS manifest intentionally uses the Lua runtime/library without the
desktop `lua[tools]` feature. The `tools` feature is host/platform-oriented
and vcpkg rejects it for the `arm64-ios` target.
