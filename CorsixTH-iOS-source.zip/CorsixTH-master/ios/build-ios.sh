#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"

: "${VCPKG_ROOT:?Set VCPKG_ROOT to your vcpkg checkout}"

cmake --preset ios-device
cmake --build build/ios-device --config Release --target CorsixTH

echo
echo "Build finished. In Xcode, select a device and sign the CorsixTH target with your own Apple account."
