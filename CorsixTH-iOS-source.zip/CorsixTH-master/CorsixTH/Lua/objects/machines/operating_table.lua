--[[ Copyright (c) 2010 Peter "Corsix" Cawley

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. --]]

local object = {}
object.id = "operating_table"
object.slave_id = "operating_table_b"
object.class = "OperatingTable"
object.thob = 30
object.research_category = "cure"
object.research_fallback = 19 -- Kidney beans
object.name = _S.object.operating_table
object.tooltip = _S.tooltip.objects.operating_table
object.ticks = false
object.build_preview_animation = 5080
object.default_strength = 8
object.crashed_animation = 3392
object.show_in_town_map = true
object.smoke_animation = 3472
local function copy_north_to_south(t)
  t.south = t.north
  return t
end
object.idle_animations = copy_north_to_south {
  north = 2314,
}
object.usage_animations = copy_north_to_south {
  north = {
    in_use = {
      Handyman = 660,
    },
  },
}
object.multi_usage_animations = {
  ["Surgeon - Gowned Male Patient"] = copy_north_to_south {
    north = {
      begin_use = 2318,
      begin_use_2 = 2322,
      in_use = 2348,
      finish_use = 2346,
      finish_use_2 = 2338,
      secondary = {
        begin_use = 416,
        finish_use_2 = 416,
      },
    },
  },
  ["Surgeon - Gowned Female Patient"] = copy_north_to_south {
    north = {
      begin_use = 2318,
      begin_use_2 = 2932,
      in_use = 2938,
      finish_use = 2936,
      finish_use_2 = 2338,
      secondary = {
        begin_use = 2886,
        finish_use_2 = 2886,
      },
    },
  },
}

local anim_mgr = TheApp.animation_manager
-- Slight hack: there seems to be no animation for a patient just lying on the
-- table, so we take a duplicate of the animation for the patient leaving the
-- table, and force its length to be 1, hence causing just the first frame to
-- be used.
anim_mgr:setAnimLength(2348, 1)
anim_mgr:setAnimLength(2938, 1)

-- Mood icon positions
anim_mgr:setPatientMarker(object.idle_animations.north, {-1.59, -2.41})
anim_mgr:setStaffMarker({2318, 2322, 2348, 2346, 2338, 2318, 2932, 2938, 2936, 2238}, {-1, -2})

anim_mgr:setStaffMarker(object.usage_animations.north.in_use.Handyman, {29, -52, "px"})


object.orientations = {
  north = {
    use_position = {-1, -2},
    use_position_secondary = {-2, -1},
    footprint = {
      {-2, -1, only_passable = true},
      {-1, -1, complete_cell = true}, {-1, -2, only_passable = true},
      {0, -1, complete_cell = true}, {0, -2, complete_cell = true},
      {1, 0, complete_cell = true}, {1, -2, complete_cell = true},  {1, -1, only_passable = true},
    },
    render_attach_position = {0, -1},
    slave_position = {1, -1},
    smoke_position = {0, 0},
  },
  east = {
    use_position = {-2, -1},
    use_position_secondary = {-1, -2},
    footprint = {
      {-1, -2, only_passable = true},
      {-1, -1, complete_cell = true}, {-2, -1, only_passable = true},
      {-1, 0, complete_cell = true}, {-2, 0, complete_cell = true},
      {0, 1, complete_cell = true}, {-2, 1, complete_cell = true},  {-1, 1, only_passable = true}, {0, 0}
    },
    slave_position = {-1, 1},
    render_attach_position = {-1, 0},
    smoke_position = {0, 0},
  },
}

class "OperatingTable" (Machine)

---@type OperatingTable
local OperatingTable = _G["OperatingTable"]

OperatingTable:slaveMixinClass()

function OperatingTable:machineUsed(...)
  -- Only if the table is the primary/master of the pair
  if not self.master then
    return Machine.machineUsed(self, ...)
  end
end

return object
