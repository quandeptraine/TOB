/*
Copyright (c) 2010-2013 Peter "Corsix" Cawley and Edvin "Lego3" Linge

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

#include "config.h"

#include <SDL3/SDL.h>
#include <ft2build.h>  // IWYU pragma: keep

#include <cmath>
// IWYU pragma: no_include "freetype/config/ftheader.h"
#ifdef WITH_TRACY
#include <tracy/Tracy.hpp>
#endif

#include <algorithm>
#include <climits>
#include <cstring>
#include <exception>
#include <new>

#include "lua.hpp"
#include "persist_lua.h"
#include "th_gfx.h"
#include "th_gfx_font.h"
#include "th_gfx_sdl.h"
#include "th_lua.h"
#include "th_lua_internal.h"
#include FT_ERRORS_H
#include FT_TYPES_H

namespace {
font* luaT_getfont(lua_State* L) {
  font* p = luaT_touserdata_base<font, bitmap_font, freetype_font>(
      L, 1, {"bitmap_font", "freetype_font"});
#ifdef DEBUG
  if (p != nullptr && dynamic_cast<bitmap_font*>(p) == nullptr &&
      dynamic_cast<freetype_font*>(p) == nullptr) {
    std::fprintf(stderr, "font found which is not freetype or bitmap: %p\n", p);
  }
#endif
  return p;
}

int l_palette_new(lua_State* L) {
  size_t iDataLen;
  const uint8_t* pData = luaT_checkfile(L, 2, &iDataLen);
  bool pal8 = lua_toboolean(L, 3);

  try {
    luaT_stdnew<palette>(L, luaT_environindex, false, pData, iDataLen, pal8);
  } catch (const std::exception& ex) {
    lua_pushstring(L, ex.what());
    lua_error(L);
  }
  return 1;
}

int l_palette_set_entry(lua_State* L) {
  palette* pPalette = luaT_testuserdata<palette>(L);
  lua_pushboolean(
      L, pPalette->set_entry(static_cast<int>(luaL_checkinteger(L, 2)),
                             static_cast<uint8_t>(luaL_checkinteger(L, 3)),
                             static_cast<uint8_t>(luaL_checkinteger(L, 4)),
                             static_cast<uint8_t>(luaL_checkinteger(L, 5)))
             ? 1
             : 0);
  return 1;
}

int l_rawbitmap_new(lua_State* L) {
  luaT_stdnew<raw_bitmap>(L, luaT_environindex, true);
  return 1;
}

int l_rawbitmap_set_pal(lua_State* L) {
  raw_bitmap* pBitmap = luaT_testuserdata<raw_bitmap>(L);
  palette* pPalette = luaT_testuserdata<palette>(L, 2);
  lua_settop(L, 2);

  pBitmap->set_palette(pPalette);
  luaT_setenvfield(L, 1, "palette");
  return 1;
}

int l_rawbitmap_load(lua_State* L) {
  ZoneScoped;

  raw_bitmap* pBitmap = luaT_testuserdata<raw_bitmap>(L);
  size_t iDataLen;
  const uint8_t* pData = luaT_checkfile(L, 2, &iDataLen);
  int iWidth = static_cast<int>(luaL_checkinteger(L, 3));
  render_target* pSurface =
      luaT_testuserdata<render_target>(L, 4, luaT_upvalueindex(1), false);

  uint32_t flags = 0;
  if (lua_type(L, 5) == LUA_TTABLE) {
    lua_getfield(L, 5, "flags");
    flags = static_cast<uint32_t>(luaL_optinteger(L, -1, 0));
    lua_pop(L, 1);
  }

  try {
    pBitmap->load_from_th_file(pData, iDataLen, iWidth, pSurface, flags);
  } catch (const std::exception& ex) {
    lua_pushstring(L, ex.what());
    lua_error(L);
    return 1;
  }

  lua_pushboolean(L, 1);
  return 1;
}

int l_rawbitmap_draw(lua_State* L) {
  ZoneScoped;

  raw_bitmap* pBitmap = luaT_testuserdata<raw_bitmap>(L);
  render_target* pCanvas = luaT_testuserdata<render_target>(L, 2);

  if (lua_gettop(L) >= 8) {
    pBitmap->draw(pCanvas, static_cast<float>(luaL_checknumber(L, 3)),
                  static_cast<float>(luaL_checknumber(L, 4)),
                  static_cast<int>(luaL_checkinteger(L, 5)),
                  static_cast<int>(luaL_checkinteger(L, 6)),
                  static_cast<int>(luaL_checkinteger(L, 7)),
                  static_cast<int>(luaL_checkinteger(L, 8)));
  } else
    pBitmap->draw(pCanvas, static_cast<float>(luaL_optnumber(L, 3, 0)),
                  static_cast<float>(luaL_optnumber(L, 4, 0)));

  lua_settop(L, 1);
  return 1;
}

int l_spritesheet_new(lua_State* L) {
  luaT_stdnew<sprite_sheet>(L, luaT_environindex, true);
  return 1;
}

int l_spritesheet_set_pal(lua_State* L) {
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);
  palette* pPalette = luaT_testuserdata<palette>(L, 2);
  lua_settop(L, 2);

  pSheet->set_palette(pPalette);
  luaT_setenvfield(L, 1, "palette");
  return 1;
}

int l_spritesheet_load(lua_State* L) {
  ZoneScoped;

  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);
  size_t iDataLenTable, iDataLenChunk;
  const uint8_t* pDataTable = luaT_checkfile(L, 2, &iDataLenTable);
  const uint8_t* pDataChunk = luaT_checkfile(L, 3, &iDataLenChunk);
  bool bComplex = lua_toboolean(L, 4) != 0;
  render_target* pSurface =
      luaT_testuserdata<render_target>(L, 5, luaT_upvalueindex(1), false);

  if (pSheet->load_from_th_file(pDataTable, iDataLenTable, pDataChunk,
                                iDataLenChunk, bComplex, pSurface))
    lua_pushboolean(L, 1);
  else
    lua_pushboolean(L, 0);

  return 1;
}

int l_spritesheet_count(lua_State* L) {
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);

  lua_pushinteger(L, pSheet->get_sprite_count());
  return 1;
}

int l_spritesheet_size(lua_State* L) {
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);
  lua_Integer iSprite = luaL_checkinteger(L, 2);  // No array adjustment
  if (iSprite < 0 ||
      iSprite >= static_cast<lua_Integer>(pSheet->get_sprite_count()))
    return luaL_argerror(L, 2, "Sprite index out of bounds");

  int iWidth;
  int iHeight;
  pSheet->get_sprite_size_unchecked(static_cast<size_t>(iSprite), &iWidth,
                                    &iHeight);

  lua_pushinteger(L, iWidth);
  lua_pushinteger(L, iHeight);
  return 2;
}

int l_spritesheet_draw(lua_State* L) {
  ZoneScoped;

  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);
  render_target* pCanvas = luaT_testuserdata<render_target>(L, 2);
  int iSprite =
      static_cast<int>(luaL_checkinteger(L, 3));  // No array adjustment

  float x = static_cast<float>(luaL_optnumber(L, 4, 0));
  float y = static_cast<float>(luaL_optnumber(L, 5, 0));

  int scale_factor = 1;
  uint32_t flags = 0;
  int arg6type = lua_type(L, 6);
  if (arg6type == LUA_TTABLE) {
    lua_getfield(L, 6, "flags");
    flags = static_cast<uint32_t>(luaL_optinteger(L, -1, 0));
    lua_pop(L, 1);

    lua_getfield(L, 6, "scaleFactor");
    scale_factor = static_cast<int>(luaL_optinteger(L, -1, 1));
    lua_pop(L, 1);
  } else if (arg6type != LUA_TNONE) {
    luaL_error(L, "Expected table for draw options");
  }

  // TODO: Support float coordinates
  pSheet->draw_sprite(pCanvas, iSprite, x, y, flags, 0, animation_effect::none,
                      scale_factor);

  lua_settop(L, 1);
  return 1;
}

int l_spritesheet_hittest(lua_State* L) {
  ZoneScoped;

  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);
  size_t iSprite = luaL_checkinteger(L, 2);
  float iX = static_cast<float>(luaL_checknumber(L, 3));
  float iY = static_cast<float>(luaL_checknumber(L, 4));
  uint32_t iFlags = static_cast<uint32_t>(luaL_optinteger(L, 5, 0));

  int x = static_cast<int>(std::roundf(iX));
  int y = static_cast<int>(std::roundf(iY));

  return pSheet->hit_test_sprite(iSprite, x, y, iFlags);
}

int l_spritesheet_isvisible(lua_State* L) {
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L);
  size_t iSprite = luaL_checkinteger(L, 2);
  lua_pushboolean(L, pSheet->is_sprite_visible(iSprite) ? 1 : 0);
  return 1;
}

int l_font_new(lua_State* L) {
  return luaL_error(L, "Cannot instantiate an interface");
}

int l_bitmap_font_new(lua_State* L) {
  luaT_stdnew<bitmap_font>(L, luaT_environindex, true);
  return 1;
}

int l_bitmap_font_set_spritesheet(lua_State* L) {
  // Note: l_freetype_font_set_spritesheet and l_bitmap_font_set_spritesheet
  // differ in their expected arguments.

  bitmap_font* pFont = luaT_testuserdata<bitmap_font>(L);
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L, 2);
  int charset_idx = static_cast<int>(luaL_optinteger(L, 3, 1));

  bitmap_font_character_set charset;
  switch (charset_idx) {
    case 1:
      charset = bitmap_font_character_set::cp437;
      break;
    case 2:
      charset = bitmap_font_character_set::mik;
      break;
    default:
      return luaL_argerror(L, 3, "Invalid character set");
  }

  lua_settop(L, 2);

  pFont->set_sprite_sheet(pSheet, charset);
  luaT_setenvfield(L, 1, "sprites");
  return 1;
}

int l_bitmap_font_get_spritesheet(lua_State* L) {
  luaT_testuserdata<bitmap_font>(L);
  luaT_getenvfield(L, 1, "sprites");
  return 1;
}

int l_bitmap_font_set_sep(lua_State* L) {
  bitmap_font* pFont = luaT_testuserdata<bitmap_font>(L);

  pFont->set_separation(static_cast<int>(luaL_checkinteger(L, 2)),
                        static_cast<int>(luaL_optinteger(L, 3, 0)));

  lua_settop(L, 1);
  return 1;
}

int l_bitmap_font_set_scale(lua_State* L) {
  bitmap_font* pFont = luaT_testuserdata<bitmap_font>(L);
  pFont->set_scale_factor(static_cast<int>(luaL_checkinteger(L, 2)));
  lua_settop(L, 1);
  return 1;
}

void l_freetype_throw_error_code(lua_State* L, FT_Error e) {
  if (e != FT_Err_Ok) {
    switch (e) {
#undef __FTERRORS_H__
#define FT_ERRORDEF(e, v, s) \
  case e:                    \
    lua_pushliteral(L, s);   \
    break;
#define FT_ERROR_START_LIST
#define FT_ERROR_END_LIST
#include FT_ERRORS_H
      default:
        lua_pushliteral(L, "Unrecognised FreeType2 error");
        break;
    };
    lua_error(L);
  }
}

int l_freetype_font_new(lua_State* L) {
  freetype_font* pFont = luaT_stdnew<freetype_font>(L, luaT_environindex, true);
  l_freetype_throw_error_code(L, pFont->initialise());
  return 1;
}

//! Read the color from the top of the Lua stack.
//! The color may be either a number representing an ARGB color, or a table
//! with fields "red", "green", "blue" and "alpha". If alpha is omitted it
//! defaults to 255 (fully opaque). All other color components default to 0
//! If neither a number nor a table is present, the color is left unchanged.
argb_colour read_color_from_lua(lua_State* L, argb_colour defaultColor) {
  argb_colour color = defaultColor;
  if (lua_istable(L, -1)) {
    lua_getfield(L, -1, "red");
    lua_getfield(L, -2, "green");
    lua_getfield(L, -3, "blue");
    lua_getfield(L, -4, "alpha");

    int red = static_cast<int>(luaL_optinteger(L, -4, 0));
    int green = static_cast<int>(luaL_optinteger(L, -3, 0));
    int blue = static_cast<int>(luaL_optinteger(L, -2, 0));
    int alpha = static_cast<int>(luaL_optinteger(L, -1, 255));
    color = palette::pack_argb(alpha, red, green, blue);
    lua_pop(L, 4);
  } else if (lua_isnumber(L, -1)) {
    color = static_cast<argb_colour>(lua_tointeger(L, -1));
    if ((color & 0xFF000000u) == 0) {
      // If no alpha was specified, assume fully opaque.
      color |= 0xFF000000u;
    }
  }
  return color;
}

//! Set the font options for a freetype font.
//!
//! The lua stack contains three arguments:
//! 1. The freetype_font userdata
//! 2. A sprite_sheet userdata used to find a default size and colour
//! 3. A table of options, which may contain:
//!    <dl>
//!    <dt>ttf_color</dt>
//!    <dd>Either a number representing an ARGB colour, or a table
//!        with fields "red", "green", "blue" and "alpha". If alpha is omitted
//!        it defaults to 255 (fully opaque). All other color components default
//!        to 0.</dd>
//!    <dt>ttf_width</dt>
//!    <dd>Desired nominal character width, in pixels. If omitted, the width is
//!    calculated from the sprite sheet.</dd>
//!    <dt>ttf_height</dt>
//!    <dd>Desired nominal character height, in pixels. If omitted, the height
//!    is calculated from the sprite sheet.</dd>
//!    <dt>ttf_shadow</dt>
//!    <dd>A table with fields "offset_x", "offset_y" and "color". The color
//!        field has the same format as ttf_color. If this field is present, the
//!        font will be drawn with a shadow of the specified colour and offset.
//!        color is optional and defaults to opaque black. offset_x and offset_y
//!        are optional and default to 1. If the field is omitted entirely, no
//!        shadow is drawn. Alternately ttf_shadow can be set to true to draw
//!        a shadow with default parameters, or false to disable any shadow.
//!        </dd>
//!    </dl>
//! @param L Lua stack
//! @return argument count
int l_freetype_font_set_font_options(lua_State* L) {
  ZoneScoped;

  // Colour 0 falls back to using the average colour of the sprite sheet.
  int width = 0;
  int height = 0;
  argb_colour color = 0;

  freetype_font* pFont = luaT_testuserdata<freetype_font>(L);
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L, 2);

  pFont->match_bitmap_font(pSheet, &color, &width, &height);

  // Optional RGB colour parameters
  lua_getfield(L, 3, "ttf_color");
  color = read_color_from_lua(L, color);
  lua_pop(L, 1);

  lua_getfield(L, 3, "ttf_width");
  if (lua_isnumber(L, -1)) {
    width = static_cast<int>(lua_tointeger(L, -1));
  }
  lua_pop(L, 1);

  lua_getfield(L, 3, "ttf_height");
  if (lua_isnumber(L, -1)) {
    height = static_cast<int>(lua_tointeger(L, -1));
  }
  lua_pop(L, 1);

  font_shadow_options shadowOptions;
  lua_getfield(L, 3, "ttf_shadow");
  if (lua_istable(L, -1)) {
    shadowOptions.enabled = true;

    lua_getfield(L, -1, "offset_x");
    shadowOptions.offset_x = static_cast<int>(luaL_optinteger(L, -1, 1));
    lua_pop(L, 1);

    lua_getfield(L, -1, "offset_y");
    shadowOptions.offset_y = static_cast<int>(luaL_optinteger(L, -1, 1));
    lua_pop(L, 1);

    lua_getfield(L, -1, "color");
    shadowOptions.color = read_color_from_lua(L, shadowOptions.color);
    lua_pop(L, 1);
  } else if (lua_isboolean(L, -1)) {
    shadowOptions.enabled = lua_toboolean(L, -1);
  }
  lua_pop(L, 1);

  lua_getfield(L, -1, "scale_factor");
  int scale_factor = static_cast<int>(luaL_optinteger(L, -1, 1));
  width *= scale_factor;
  height *= scale_factor;
  shadowOptions.offset_x *= scale_factor;
  shadowOptions.offset_y *= scale_factor;
  lua_pop(L, 1);

  pFont->set_font_color(color);
  pFont->set_shadow_options(shadowOptions);
  l_freetype_throw_error_code(L,
                              pFont->set_ideal_character_size(width, height));
  lua_settop(L, 1);
  return 1;
}

int l_freetype_font_get_copyright(lua_State* L) {
  lua_pushstring(L, freetype_font::get_copyright_notice());
  return 1;
}

int l_freetype_font_set_face(lua_State* L) {
  freetype_font* pFont = luaT_testuserdata<freetype_font>(L);
  size_t iLength;
  const uint8_t* pData = luaT_checkfile(L, 2, &iLength);
  lua_settop(L, 2);

  l_freetype_throw_error_code(L, pFont->set_face(pData, iLength));
  luaT_setenvfield(L, 1, "face");
  return 1;
}

int l_freetype_font_clear_cache(lua_State* L) {
  freetype_font* pFont = luaT_testuserdata<freetype_font>(L);
  pFont->clear_cache();
  return 0;
}

int l_font_get_size(lua_State* L) {
  font* pFont = luaT_getfont(L);
  size_t iMsgLen;
  const char* sMsg = luaT_checkstring(L, 2, &iMsgLen);

  ZoneScoped;

  int iMaxWidth = INT_MAX;
  if (!lua_isnoneornil(L, 3))
    iMaxWidth = static_cast<int>(luaL_checkinteger(L, 3));

  text_layout oDrawArea = pFont->get_text_dimensions(sMsg, iMsgLen, iMaxWidth);

  lua_pushinteger(L, oDrawArea.end_x);
  lua_pushinteger(L, oDrawArea.end_y);
  lua_pushinteger(L, oDrawArea.row_count);

  return 3;
}

int l_font_draw(lua_State* L) {
  ZoneScoped;

  font* pFont = luaT_getfont(L);
  render_target* pCanvas = nullptr;
  if (!lua_isnoneornil(L, 2)) {
    pCanvas = luaT_testuserdata<render_target>(L, 2);
  }
  size_t iMsgLen;
  const char* sMsg = luaT_checkstring(L, 3, &iMsgLen);
  float iX = static_cast<float>(luaL_checknumber(L, 4));
  float iY = static_cast<float>(luaL_checknumber(L, 5));

  text_alignment eAlign = text_alignment::center;
  if (!lua_isnoneornil(L, 8)) {
    const char* sAlign = luaL_checkstring(L, 8);
    if (std::strcmp(sAlign, "right") == 0) {
      eAlign = text_alignment::right;
    } else if (std::strcmp(sAlign, "left") == 0) {
      eAlign = text_alignment::left;
    } else if (std::strcmp(sAlign, "center") == 0 ||
               std::strcmp(sAlign, "centre") == 0 ||
               std::strcmp(sAlign, "middle") == 0) {
      eAlign = text_alignment::center;
    } else {
      return luaL_error(L, "Invalid alignment: \"%s\"", sAlign);
    }
  }

  text_layout oDrawArea = pFont->get_text_dimensions(sMsg, iMsgLen);
  float area_endx = static_cast<float>(oDrawArea.end_x);
  float area_endy = static_cast<float>(oDrawArea.end_y);
  if (!lua_isnoneornil(L, 7)) {
    int iW = static_cast<int>(luaL_checkinteger(L, 6));
    int iH = static_cast<int>(luaL_checkinteger(L, 7));
    if (iW > oDrawArea.end_x && eAlign != text_alignment::left) {
      iX += std::ceil((static_cast<float>(iW) - area_endx) /
                      ((eAlign == text_alignment::center) ? 2.0f : 1.0f));
    }
    if (iH > oDrawArea.end_y) {
      iY += std::ceil((static_cast<float>(iH) - area_endy) / 2);
    }
  }
  if (pCanvas != nullptr) {
    pFont->draw_text(pCanvas, sMsg, iMsgLen, iX, iY);
  }
  lua_pushnumber(L, iY + area_endy);
  lua_pushnumber(L, iX + area_endx);

  return 2;
}

int l_font_draw_wrapped(lua_State* L) {
  ZoneScoped;

  font* pFont = luaT_getfont(L);
  render_target* pCanvas = nullptr;
  if (!lua_isnoneornil(L, 2)) {
    pCanvas = luaT_testuserdata<render_target>(L, 2);
  }
  size_t iMsgLen;
  const char* sMsg = luaT_checkstring(L, 3, &iMsgLen);
  float iX = static_cast<float>(luaL_checknumber(L, 4));
  float iY = static_cast<float>(luaL_checknumber(L, 5));
  int iW = static_cast<int>(luaL_checkinteger(L, 6));

  text_alignment eAlign = text_alignment::left;
  if (!lua_isnoneornil(L, 7)) {
    const char* sAlign = luaL_checkstring(L, 7);
    if (std::strcmp(sAlign, "right") == 0) {
      eAlign = text_alignment::right;
    } else if (std::strcmp(sAlign, "left") == 0) {
      eAlign = text_alignment::left;
    } else if (std::strcmp(sAlign, "center") == 0 ||
               std::strcmp(sAlign, "centre") == 0 ||
               std::strcmp(sAlign, "middle") == 0) {
      eAlign = text_alignment::center;
    } else {
      return luaL_error(L, "Invalid alignment: \"%s\"", sAlign);
    }
  }

  int iMaxRows = INT_MAX;
  if (!lua_isnoneornil(L, 8)) {
    iMaxRows = static_cast<int>(luaL_checkinteger(L, 8));
  }

  int iSkipRows = 0;
  if (!lua_isnoneornil(L, 9)) {
    iSkipRows = static_cast<int>(luaL_checkinteger(L, 9));
  }

  text_layout oDrawArea = pFont->draw_text_wrapped(
      pCanvas, sMsg, iMsgLen, iX, iY, iW, iMaxRows, iSkipRows, eAlign);
  lua_pushinteger(L, oDrawArea.end_y);
  lua_pushinteger(L, oDrawArea.end_x);
  lua_pushinteger(L, oDrawArea.row_count);

  return 3;
}

int l_font_draw_tooltip(lua_State* L) {
  ZoneScoped;

  font* pFont = luaT_getfont(L);
  render_target* pCanvas = luaT_testuserdata<render_target>(L, 2);
  size_t iMsgLen;
  const char* sMsg = luaT_checkstring(L, 3, &iMsgLen);
  float iX = static_cast<float>(luaL_checknumber(L, 4));
  float iY = static_cast<float>(luaL_checknumber(L, 5));
  int iW = static_cast<int>(luaL_optinteger(L, 6, 200));
  float screen_width = static_cast<float>(pCanvas->get_size().width);

  // Pixel align tooltips to avoid fuzzy text
  iX = std::roundf(iX);
  iY = std::roundf(iY);

  uint32_t iBlack = render_target::map_colour(0x00, 0x00, 0x00);
  uint32_t iWhite = render_target::map_colour(0xFF, 0xFF, 0xFF);
  text_layout oArea = pFont->draw_text_wrapped(nullptr, sMsg, iMsgLen, iX + 2,
                                               iY + 1, iW - 4, INT_MAX, 0);

  float area_width = static_cast<float>(oArea.width);
  float area_endy = static_cast<float>(oArea.end_y);
  float iLastX = iX + area_width + 3;
  float iFirstY = iY - (area_endy - iY) - 1;

  float iXOffset = iLastX > screen_width ? screen_width - iLastX : 0;
  float iYOffset = iFirstY < 0 ? -iFirstY : 0;

  pCanvas->fill_rect(iBlack, iX + iXOffset, iFirstY + iYOffset, area_width + 3,
                     area_endy - iY + 2);
  pCanvas->fill_rect(iWhite, iX + iXOffset + 1, iFirstY + 1 + iYOffset,
                     area_width + 1, area_endy - iY);

  pFont->draw_text_wrapped(pCanvas, sMsg, iMsgLen, iX + 2 + iXOffset,
                           iFirstY + 1 + iYOffset, iW - 4);

  lua_pushinteger(L, oArea.end_y);

  return 1;
}

int l_font_is_bitmap(lua_State* L) {
  font* pFont = luaT_getfont(L);
  lua_pushboolean(L, dynamic_cast<bitmap_font*>(pFont) != nullptr ? 1 : 0);
  return 1;
}

int l_layers_new(lua_State* L) {
  layers* pLayers = luaT_stdnew<layers>(L, luaT_environindex, false);
  for (int i = 0; i < max_number_of_layers; ++i) pLayers->layer_contents[i] = 0;
  return 1;
}

int l_layers_get(lua_State* L) {
  layers* pLayers = luaT_testuserdata<layers>(L);
  lua_Integer iLayer = luaL_checkinteger(L, 2);
  if (0 <= iLayer && iLayer < max_number_of_layers)
    lua_pushinteger(L, pLayers->layer_contents[iLayer]);
  else
    lua_pushnil(L);
  return 1;
}

int l_layers_set(lua_State* L) {
  layers* pLayers = luaT_testuserdata<layers>(L);
  lua_Integer iLayer = luaL_checkinteger(L, 2);
  uint8_t iValue = static_cast<uint8_t>(luaL_checkinteger(L, 3));
  if (0 <= iLayer && iLayer < max_number_of_layers) {
    pLayers->layer_contents[iLayer] = iValue;
  }
  return 0;
}

int l_layers_persist(lua_State* L) {
  layers* pLayers = luaT_testuserdata<layers>(L);
  lua_persist_writer* pWriter = (lua_persist_writer*)lua_touserdata(L, 2);

  int iNumLayers = max_number_of_layers;
  for (; iNumLayers >= 1; --iNumLayers) {
    if (pLayers->layer_contents[iNumLayers - 1] != 0) break;
  }
  pWriter->write_uint(iNumLayers);
  pWriter->write_byte_stream(pLayers->layer_contents, iNumLayers);
  return 0;
}

int l_layers_depersist(lua_State* L) {
  void* layers_ud = luaT_testuserdata<layers>(L);
  lua_settop(L, 2);
  lua_insert(L, 1);
  lua_persist_reader* pReader =
      static_cast<lua_persist_reader*>(lua_touserdata(L, 1));

  layers* ls = new (layers_ud) layers();
  int iNumLayers;
  if (!pReader->read_uint(iNumLayers)) return 0;
  if (iNumLayers > max_number_of_layers) {
    if (!pReader->read_byte_stream(ls->layer_contents, max_number_of_layers)) {
      return 0;
    }
    if (!pReader->read_byte_stream(nullptr,
                                   iNumLayers - max_number_of_layers)) {
      return 0;
    }
  } else {
    if (!pReader->read_byte_stream(ls->layer_contents, iNumLayers)) return 0;
  }
  return 0;
}

int l_cursor_new(lua_State* L) {
  luaT_stdnew<cursor>(L, luaT_environindex, false);
  return 1;
}

int l_cursor_load(lua_State* L) {
  ZoneScoped;

  cursor* pCursor = luaT_testuserdata<cursor>(L);
  sprite_sheet* pSheet = luaT_testuserdata<sprite_sheet>(L, 2);
  if (pCursor->create_from_sprite(pSheet,
                                  static_cast<int>(luaL_checkinteger(L, 3)),
                                  static_cast<int>(luaL_optinteger(L, 4, 0)),
                                  static_cast<int>(luaL_optinteger(L, 5, 0)))) {
    lua_settop(L, 1);
    return 1;
  } else {
    lua_pushboolean(L, 0);
    return 1;
  }
}

int l_cursor_use(lua_State* L) {
  cursor* pCursor = luaT_testuserdata<cursor>(L);
  render_target* pCanvas = luaT_testuserdata<render_target>(L, 2);
  pCursor->use(pCanvas);
  return 0;
}

int l_cursor_position(lua_State* L) {
  render_target* pCanvas =
      luaT_testuserdata<render_target>(L, 1, luaT_upvalueindex(1));
  lua_pushboolean(L, cursor::set_position(
                         pCanvas, static_cast<float>(luaL_checknumber(L, 2)),
                         static_cast<float>(luaL_checknumber(L, 3)))
                         ? 1
                         : 0);
  return 1;
}

bool is_table_field_true(lua_State* L, int table_index, const char* key) {
  lua_getfield(L, table_index, key);
  bool result = lua_toboolean(L, -1);
  lua_pop(L, 1);
  return result;
}

/** Construct the helper structure for making a #THRenderTarget. */
render_target_creation_params l_surface_creation_params(lua_State* L,
                                                        int iArgStart) {
  window_size size = {static_cast<int>(luaL_checkinteger(L, iArgStart)),
                      static_cast<int>(luaL_checkinteger(L, iArgStart + 1))};

  window_size min_size = {
      static_cast<int>(luaL_checkinteger(L, iArgStart + 2)),
      static_cast<int>(luaL_checkinteger(L, iArgStart + 3))};

  render_target_creation_params params{};
  params.size = size;
  params.min_size = min_size;

  // Parse the modes
  int modes_idx = iArgStart + 4;
  if (!lua_istable(L, modes_idx)) {
    return params;
  }
  params.fullscreen = is_table_field_true(L, modes_idx, "fullscreen");
  params.maximized = is_table_field_true(L, modes_idx, "maximized");
  params.present_immediate =
      is_table_field_true(L, modes_idx, "present_immediate");
  params.direct_zoom = is_table_field_true(L, modes_idx, "direct_zoom");
  params.aspect_ratio_4_3 =
      is_table_field_true(L, modes_idx, "aspect_ratio_4_3");
  params.hidpi = is_table_field_true(L, modes_idx, "hidpi");
  lua_pop(L, 1);

  return params;
}

int l_surface_new(lua_State* L) {
  lua_remove(L, 1);  // Value inserted by __call

  render_target_creation_params params = l_surface_creation_params(L, 1);
  try {
    luaT_stdnew<render_target>(L, luaT_environindex, false, params);
  } catch (const std::exception& ex) {
    return luaL_error(L, "Could not create render target: %s", ex.what());
  }

  return 1;
}

int l_surface_update(lua_State* L) {
  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  render_target_creation_params params = l_surface_creation_params(L, 2);
  if (pCanvas->update(params)) {
    lua_pushnil(L);
    return 1;
  }

  lua_pushstring(L, pCanvas->get_last_error());
  return 1;
}

int l_surface_fill_black(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  lua_settop(L, 1);
  if (pCanvas->fill_black()) return 1;
  lua_pushnil(L);
  lua_pushstring(L, pCanvas->get_last_error());
  return 2;
}

int l_surface_fill_colour(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  uint32_t c = read_color_from_lua(L, 0xFF000000);
  lua_settop(L, 2);
  if (pCanvas->fill_colour(c)) return 1;
  lua_pushnil(L);
  lua_pushstring(L, pCanvas->get_last_error());
  return 2;
}

int l_surface_start_frame(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  lua_settop(L, 1);
  if (pCanvas->start_frame()) return 1;
  lua_pushnil(L);
  lua_pushstring(L, pCanvas->get_last_error());
  return 2;
}

int l_surface_end_frame(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  lua_settop(L, 1);
  if (pCanvas->end_frame()) return 1;
  lua_pushnil(L);
  lua_pushstring(L, pCanvas->get_last_error());
  return 2;
}

int l_surface_nonoverlapping(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  if (lua_isnone(L, 2) || lua_toboolean(L, 2) != 0)
    pCanvas->start_nonoverlapping_draws();
  else
    pCanvas->finish_nonoverlapping_draws();
  lua_settop(L, 1);
  return 1;
}

int l_surface_set_blue_filter_active(lua_State* L) {
  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  pCanvas->set_blue_filter_active(
      (lua_isnoneornil(L, 2) != 0) ? false : (lua_toboolean(L, 2) != 0));
  return 1;
}

int l_surface_map(lua_State* L) {
  ZoneScoped;

  lua_pushnumber(
      L, (lua_Number)render_target::map_colour((Uint8)luaL_checkinteger(L, 2),
                                               (Uint8)luaL_checkinteger(L, 3),
                                               (Uint8)luaL_checkinteger(L, 4)));
  return 1;
}

int l_surface_rect(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  if (pCanvas->fill_rect(static_cast<uint32_t>(luaL_checkinteger(L, 2)),
                         static_cast<float>(luaL_checknumber(L, 3)),
                         static_cast<float>(luaL_checknumber(L, 4)),
                         static_cast<float>(luaL_checknumber(L, 5)),
                         static_cast<float>(luaL_checknumber(L, 6)))) {
    lua_settop(L, 1);
    return 1;
  }
  lua_pushnil(L);
  lua_pushstring(L, pCanvas->get_last_error());
  return 2;
}

int l_surface_screenshot(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  const char* file_path = luaL_checkstring(L, 2);
  if (pCanvas->take_screenshot(file_path)) {
    lua_settop(L, 1);
    return 1;
  }
  lua_pushnil(L);
  lua_pushstring(L, pCanvas->get_last_error());
  return 2;
}

int l_surface_push_clip(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  clip_rect rcClip;
  rcClip.x = static_cast<clip_rect::x_y_type>(luaL_checkinteger(L, 2));
  rcClip.y = static_cast<clip_rect::x_y_type>(luaL_checkinteger(L, 3));
  rcClip.w = static_cast<clip_rect::w_h_type>(luaL_checkinteger(L, 4));
  rcClip.h = static_cast<clip_rect::w_h_type>(luaL_checkinteger(L, 5));
  pCanvas->push_clip_rect(&rcClip);
  lua_settop(L, 1);
  return 1;
}

int l_surface_pop_clip(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  pCanvas->pop_clip_rect();
  lua_settop(L, 1);
  return 1;
}

int l_surface_get_render_size(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  auto [width, height] = pCanvas->get_size();
  lua_pushinteger(L, width);
  lua_pushinteger(L, height);
  return 2;
}

int l_surface_get_window_size(lua_State* L) {
  ZoneScoped;

  render_target* canvas = luaT_testuserdata<render_target>(L);
  auto [width, height] = canvas->get_window_size();
  lua_pushinteger(L, width);
  lua_pushinteger(L, height);
  return 2;
}

int l_surface_get_max_window_size(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  auto [width, height] = pCanvas->get_max_window_size();
  lua_pushinteger(L, width);
  lua_pushinteger(L, height);
  return 2;
}

int l_surface_get_display_scale(lua_State* L) {
  render_target* canvas = luaT_testuserdata<render_target>(L);
  lua_pushnumber(L, canvas->get_display_scale());
  return 1;
}

int l_surface_scale(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  scaled_items eToScale = scaled_items::none;
  if (lua_isnoneornil(L, 3)) {
    eToScale = scaled_items::all;
  } else {
    size_t iLength;
    const char* sOption = lua_tolstring(L, 3, &iLength);
    if (sOption && iLength >= 6 && std::memcmp(sOption, "bitmap", 6) == 0) {
      eToScale = scaled_items::bitmaps;
    } else
      luaL_error(L, "Expected \"bitmap\" as 2nd argument");
  }
  lua_pushboolean(L, pCanvas->set_scale_factor(
                         static_cast<float>(luaL_checknumber(L, 2)), eToScale)
                         ? 1
                         : 0);
  return 1;
}

int l_surface_set_caption(lua_State* L) {
  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  pCanvas->set_caption(luaL_checkstring(L, 2));

  lua_settop(L, 1);
  return 1;
}

int l_surface_get_renderer_details(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  lua_pushstring(L, pCanvas->get_renderer_details());
  return 1;
}

// Lua to THRenderTarget->setWindowGrab
int l_surface_set_capture_mouse(lua_State* L) {
  ZoneScoped;

  render_target* pCanvas = luaT_testuserdata<render_target>(L);
  pCanvas->set_window_grab(
      (lua_isnoneornil(L, 2) != 0) ? false : (lua_toboolean(L, 2) != 0));
  return 0;
}

int l_line_new(lua_State* L) {
  luaT_stdnew<line_sequence>(L);
  return 1;
}

int l_move_to(lua_State* L) {
  line_sequence* pLine = luaT_testuserdata<line_sequence>(L);
  pLine->move_to(luaL_optnumber(L, 2, 0), luaL_optnumber(L, 3, 0));

  lua_settop(L, 1);
  return 1;
}

int l_line_to(lua_State* L) {
  line_sequence* pLine = luaT_testuserdata<line_sequence>(L);
  pLine->line_to(luaL_optnumber(L, 2, 0), luaL_optnumber(L, 3, 0));

  lua_settop(L, 1);
  return 1;
}

int l_set_width(lua_State* L) {
  line_sequence* pLine = luaT_testuserdata<line_sequence>(L);
  pLine->set_width(luaL_optnumber(L, 2, 1));

  lua_settop(L, 1);
  return 1;
}

int l_set_colour(lua_State* L) {
  line_sequence* pLine = luaT_testuserdata<line_sequence>(L);
  pLine->set_colour(static_cast<uint8_t>(luaL_optinteger(L, 2, 0)),
                    static_cast<uint8_t>(luaL_optinteger(L, 3, 0)),
                    static_cast<uint8_t>(luaL_optinteger(L, 4, 0)),
                    static_cast<uint8_t>(luaL_optinteger(L, 5, 255)));

  lua_settop(L, 1);
  return 1;
}

int l_line_draw(lua_State* L) {
  ZoneScoped;

  line_sequence* pLine = luaT_testuserdata<line_sequence>(L);
  render_target* pCanvas = luaT_testuserdata<render_target>(L, 2);
  pLine->draw(pCanvas, static_cast<float>(luaL_optnumber(L, 3, 0)),
              static_cast<float>(luaL_optnumber(L, 4, 0)));

  lua_settop(L, 1);
  return 1;
}

int l_line_persist(lua_State* L) {
  line_sequence* pLine = luaT_testuserdata<line_sequence>(L);
  lua_persist_writer* pWriter = (lua_persist_writer*)lua_touserdata(L, 2);
  pLine->persist(pWriter);
  return 0;
}

int l_line_depersist(lua_State* L) {
  void* line_ud = luaT_testuserdata<line_sequence>(L);
  lua_settop(L, 2);
  lua_insert(L, 1);
  lua_persist_reader* pReader =
      static_cast<lua_persist_reader*>(lua_touserdata(L, 1));
  line_sequence* line = new (line_ud) line_sequence();
  line->depersist(pReader);
  return 0;
}

}  // namespace

void lua_register_gfx(const lua_register_state* pState) {
  // Palette
  {
    lua_class_binding<palette> lcb(pState, "palette", l_palette_new,
                                   lua_metatable::palette);
    lcb.add_function(l_palette_set_entry, "setEntry");
  }

  // Raw bitmap
  {
    lua_class_binding<raw_bitmap> lcb(pState, "bitmap", l_rawbitmap_new,
                                      lua_metatable::bitmap);
    lcb.add_function(l_rawbitmap_load, "load", lua_metatable::surface);
    lcb.add_function(l_rawbitmap_set_pal, "setPalette", lua_metatable::palette);
    lcb.add_function(l_rawbitmap_draw, "draw", lua_metatable::surface);
  }

  // Sprite sheet
  {
    lua_class_binding<sprite_sheet> lcb(pState, "sheet", l_spritesheet_new,
                                        lua_metatable::sheet);
    lcb.add_metamethod(l_spritesheet_count, "len");
    lcb.add_function(l_spritesheet_load, "load", lua_metatable::surface);
    lcb.add_function(l_spritesheet_set_pal, "setPalette",
                     lua_metatable::palette);
    lcb.add_function(l_spritesheet_size, "size");
    lcb.add_function(l_spritesheet_draw, "draw", lua_metatable::surface);
    lcb.add_function(l_spritesheet_hittest, "hitTest");
    lcb.add_function(l_spritesheet_isvisible, "isVisible");
  }

  // Font
  // Also adapt the font proxy meta table (font_proxy_mt) in graphics.lua.
  {
    lua_class_binding<font> lcb(pState, "font", l_font_new,
                                lua_metatable::font);
    lcb.add_function(l_font_get_size, "sizeOf");
    lcb.add_function(l_font_draw, "draw", lua_metatable::surface);
    lcb.add_function(l_font_draw_wrapped, "drawWrapped",
                     lua_metatable::surface);
    lcb.add_function(l_font_draw_tooltip, "drawTooltip",
                     lua_metatable::surface);
    lcb.add_function(l_font_is_bitmap, "isBitmap");
  }

  // BitmapFont
  {
    lua_class_binding<bitmap_font> lcb(pState, "bitmap_font", l_bitmap_font_new,
                                       lua_metatable::bitmap_font);
    lcb.set_superclass(lua_metatable::font);
    lcb.add_function(l_bitmap_font_set_spritesheet, "setSheet",
                     lua_metatable::sheet);
    lcb.add_function(l_bitmap_font_get_spritesheet, "getSheet",
                     lua_metatable::sheet);
    lcb.add_function(l_bitmap_font_set_sep, "setSeparation");
    lcb.add_function(l_bitmap_font_set_scale, "setScaleFactor");
  }

  // FreeTypeFont
  {
    lua_class_binding<freetype_font> lcb(pState, "freetype_font",
                                         l_freetype_font_new,
                                         lua_metatable::freetype_font);
    lcb.set_superclass(lua_metatable::font);
    lcb.add_function(l_freetype_font_set_font_options, "setFontOptions",
                     lua_metatable::sheet);
    lcb.add_function(l_freetype_font_set_face, "setFace");
    lcb.add_function(l_freetype_font_get_copyright, "getCopyrightNotice");
    lcb.add_function(l_freetype_font_clear_cache, "clearCache");
  }

  // Layers
  {
    lua_class_binding<layers> lcb(pState, "layers", l_layers_new,
                                  lua_metatable::layers);
    lcb.add_metamethod(l_layers_get, "index");
    lcb.add_metamethod(l_layers_set, "newindex");
    lcb.add_metamethod(l_layers_persist, "persist");
    lcb.add_metamethod(l_layers_depersist, "depersist");
  }

  // Cursor
  {
    lua_class_binding<cursor> lcb(pState, "cursor", l_cursor_new,
                                  lua_metatable::cursor);
    lcb.add_function(l_cursor_load, "load", lua_metatable::sheet);
    lcb.add_function(l_cursor_use, "use", lua_metatable::surface);
    lcb.add_function(l_cursor_position, "setPosition", lua_metatable::surface);
  }

  // Surface
  {
    lua_class_binding<render_target> lcb(pState, "surface", l_surface_new,
                                         lua_metatable::surface);
    lcb.add_function(l_surface_update, "update");
    lcb.add_function(l_surface_fill_black, "fillBlack");
    lcb.add_function(l_surface_fill_colour, "fillColour");
    lcb.add_function(l_surface_start_frame, "startFrame");
    lcb.add_function(l_surface_end_frame, "endFrame");
    lcb.add_function(l_surface_nonoverlapping, "nonOverlapping");
    lcb.add_function(l_surface_map, "mapRGB");
    lcb.add_function(l_surface_set_blue_filter_active, "setBlueFilterActive");
    lcb.add_function(l_surface_rect, "drawRect");
    lcb.add_function(l_surface_push_clip, "pushClip");
    lcb.add_function(l_surface_pop_clip, "popClip");
    lcb.add_function(l_surface_get_render_size, "getRenderSize");
    lcb.add_function(l_surface_get_window_size, "getWindowSize");
    lcb.add_function(l_surface_get_max_window_size, "getMaxWindowSize");
    lcb.add_function(l_surface_get_display_scale, "getWindowDisplayScale");
    lcb.add_function(l_surface_screenshot, "takeScreenshot");
    lcb.add_function(l_surface_scale, "scale");
    lcb.add_function(l_surface_set_caption, "setCaption");
    lcb.add_function(l_surface_get_renderer_details, "getRendererDetails");
    lcb.add_function(l_surface_set_capture_mouse, "setCaptureMouse");
  }

  // Line
  {
    lua_class_binding<line_sequence> lcb(pState, "line", l_line_new,
                                         lua_metatable::line);
    lcb.add_function(l_move_to, "moveTo");
    lcb.add_function(l_line_to, "lineTo");
    lcb.add_function(l_set_width, "setWidth");
    lcb.add_function(l_set_colour, "setColour");
    lcb.add_function(l_line_draw, "draw", lua_metatable::surface);
    lcb.add_metamethod(l_line_persist, "persist");
    lcb.add_metamethod(l_line_depersist, "depersist");
  }
}
