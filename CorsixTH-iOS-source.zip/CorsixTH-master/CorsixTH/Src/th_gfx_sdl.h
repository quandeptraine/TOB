/*
Copyright (c) 2009-2013 Peter "Corsix" Cawley and Edvin "Lego3" Linge

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

#ifndef CORSIX_TH_TH_GFX_SDL_H_
#define CORSIX_TH_TH_GFX_SDL_H_

#include "config.h"

#include <SDL3/SDL.h>

#include <array>
#include <memory>
#include <stack>
#include <stdexcept>
#include <vector>

#include "th_gfx_common.h"

class cursor;
class line_sequence;
class lua_persist_reader;
class lua_persist_writer;

struct clip_rect : public SDL_Rect {
  typedef Sint16 x_y_type;
  typedef Uint16 w_h_type;
};

/**
 * A size (width x height) in Window coordinates
 */
struct window_size {
  int width;
  int height;
};

/**
 * A size (width x height) in Render coordinates (pixels)
 */
struct render_size {
  int width;
  int height;
};

/** Helper structure with parameters to create a #render_target. */
struct render_target_creation_params {
  window_size size{};        ///< Target size of the window.
  bool fullscreen{};         ///< Run fullscreen.
  bool maximized{};          ///< Run maximized (when not fullscreen).
  bool aspect_ratio_4_3{};   ///< Display the game letterboxed to 4:3
  bool present_immediate{};  ///< Whether to present immediately to the user
                             ///< (else wait for Vsync).
  bool direct_zoom{};        ///< Scale each texture when copying if true,
                             ///< otherwise render to intermediate texture and
                             ///< scale.
  bool hidpi{};              ///< Enable HiDPI on the game window.
  window_size min_size{};    ///< Minimum size of the window.
};

enum class scaled_items;

//! 32bpp ARGB colour. See #palette::pack_argb
typedef uint32_t argb_colour;

//! 8bpp palette class.
class palette {
 public:  // External API
  //! Number of colours in the palette.
  static constexpr int color_count{256};

  //! Create an empty palette. All entries are black and fully opaque.
  palette() = default;

  //! Load a 256 index color palette from the supplied data.
  /*!
      @param pData Palette data in RGB or RGBA format.
      @param iDataLength Size of the data.
      @param is8bit Whether the data is in 8bpp (otherwise 6bpp).
      @return Whether loading of the palette succeeded.
  */
  palette(const uint8_t* pData, size_t iDataLength, bool is8bit);

  //! Set an entry of the palette.
  /*!
      The RGB colour (255, 0, 255) is used as the transparent colour.
      @param iEntry Entry number to change.
      @param iR Amount of red in the new entry.
      @param iG Amount of green in the new entry.
      @param iB Amount of blue in the new entry.
      @return Setting the entry succeeded.
  */
  bool set_entry(int iEntry, uint8_t iR, uint8_t iG, uint8_t iB);

 public:  // Internal (this rendering engine only) API
  //! Convert A, R, G, B values to a 32bpp colour.
  /*!
      @param iA Amount of opacity (0-255).
      @param iR Amount of red (0-255).
      @param iG Amount of green (0-255).
      @param iB Amount of blue (0-255).
      @return 32bpp value representing the provided colour values.
  */
  static constexpr argb_colour pack_argb(uint8_t iA, uint8_t iR, uint8_t iG,
                                         uint8_t iB) {
    return (static_cast<argb_colour>(iR) << 0) |
           (static_cast<argb_colour>(iG) << 8) |
           (static_cast<argb_colour>(iB) << 16) |
           (static_cast<argb_colour>(iA) << 24);
  }

  //! Get the red component of a colour.
  /*!
      @param iColour Colour to examine.
      @return The red component intensity of the colour.
  */
  static constexpr uint8_t get_red(argb_colour iColour) {
    return static_cast<uint8_t>((iColour >> 0) & 0xFF);
  }

  //! Get the green component of a colour.
  /*!
      @param iColour Colour to examine.
      @return The green component intensity of the colour.
  */
  static constexpr uint8_t get_green(argb_colour iColour) {
    return static_cast<uint8_t>((iColour >> 8) & 0xFF);
  }

  //! Get the blue component of a colour.
  /*!
      @param iColour Colour to examine.
      @return The blue component intensity of the colour.
  */
  static constexpr uint8_t get_blue(argb_colour iColour) {
    return static_cast<uint8_t>((iColour >> 16) & 0xFF);
  }

  //! Get the opacity component of a colour.
  /*!
      @param iColour Colour to examine.
      @return The opacity of the colour.
  */
  static constexpr uint8_t get_alpha(argb_colour iColour) {
    return static_cast<uint8_t>((iColour >> 24) & 0xFF);
  }

  //! Get the internal palette data for fast (read-only) access.
  /*!
      @return Table with all 256 colours of the palette.
  */
  const std::array<argb_colour, color_count>& get_argb_data() const;

  //! Set an entry of the palette.
  /*!
      @param iEntry Entry to modify.
      @param iVal Palette value to set.
  */
  inline void set_argb(int iEntry, uint32_t iVal) {
    colour_index_to_argb_map[iEntry] = iVal;
  }

 private:
  //! 32bpp palette colours associated with the 8bpp colour index.
  std::array<argb_colour, color_count> colour_index_to_argb_map{};
};

/*!
    Utility class for decoding 32bpp images.
*/
class full_colour_renderer {
 public:
  //! Initialize the renderer for a specific render.
  /*!
      @param iWidth Pixel width of the resulting image
      @param iHeight Pixel height of the resulting image
  */
  full_colour_renderer(int iWidth, int iHeight);
  virtual ~full_colour_renderer() = default;

  //! Decode a 32bpp image, and push it to the storage backend.
  /*!
      @param pImg Encoded 32bpp image.
      @param pPalette Palette of a legacy sprite.
      @param iSpriteFlags Flags how to render the sprite.
      @return Decoding was successful.
  */
  void decode_image(const uint8_t* pImg, const ::palette* pPalette,
                    uint32_t iSpriteFlags);

 private:
  //! Store a decoded pixel. Use x and y if necessary.
  /*!
      @param pixel Pixel to store.
  */
  virtual void store_argb(uint32_t pixel) = 0;

  const int width;
  const int height;
  int x{};
  int y{};

  //! Push a pixel to the storage.
  /*!
      @param iValue Pixel value to store.
  */
  inline void push_pixel(uint32_t iValue) {
    if (y < height) {
      store_argb(iValue);
      x++;
      if (x >= width) {
        x = 0;
        y++;
      }
    } else {
      throw std::logic_error("Attempt to push_pixel past the end of the image");
    }
  }
};

class full_colour_storing : public full_colour_renderer {
 public:
  full_colour_storing(uint32_t* pDest, int iWidth, int iHeight);

 private:
  void store_argb(uint32_t pixel) override;

  //! Pointer to the storage (not owned by this class).
  uint32_t* destination;
};

class wx_storing : public full_colour_renderer {
 public:
  wx_storing(uint8_t* pRGBData, uint8_t* pAData, int iWidth, int iHeight);

 private:
  void store_argb(uint32_t pixel) override;

  //! Pointer to the RGB storage (not owned by this class).
  uint8_t* rgb_data;

  //! Pointer to the Alpha channel storage (not owned by this class).
  uint8_t* alpha_data;
};

class render_target {
 public:  // External API
  explicit render_target(const render_target_creation_params& params);
  render_target(const render_target& other) = delete;
  render_target& operator=(const render_target& other) = delete;
  ~render_target();

  //! Encode an RGB triplet for fillRect()
  static constexpr uint32_t map_colour(uint8_t iR, uint8_t iG, uint8_t iB) {
    return palette::pack_argb(0xFF, iR, iG, iB);
  }

  //! Update the parameters for the render target
  bool update(const render_target_creation_params& params);

  //! Update the render target when the size changes
  void on_pixel_size_change();

  //! Get the reason for the last operation failing
  const char* get_last_error();

  //! Begin rendering a new frame
  bool start_frame();

  //! Finish rendering the current frame and present it
  bool end_frame();

  //! Paint the entire render target black
  bool fill_black();

  //! Paint the entire render target with a solid colour
  bool fill_colour(uint32_t colour);

  //! Sets a blue filter on the current surface.
  // Used to add the blue effect when the game is paused.
  void set_blue_filter_active(bool bActivate);

  //! Fill a rectangle of the render target with a solid colour
  bool fill_rect(uint32_t iColour, float iX, float iY, float iW, float iH);

  class scoped_clip {
   public:
    scoped_clip(render_target*, const clip_rect* pRect);
    ~scoped_clip();

   private:
    render_target* target{nullptr};
  };

  //! Push a new clip rectangle.
  void push_clip_rect(const clip_rect* pRect);

  //! Restore the previous clip rectangle.
  void pop_clip_rect();

  //! Get the size of the render viewport (in pixels)
  render_size get_size() const;

  //! Get the width of the render target adjusted by the current scale factor
  int get_scaled_width() const;

  //! Get the height of the render target adjusted by the current scale factor
  int get_scaled_height() const;

  //! Get the current window size (in window coordinates)
  window_size get_window_size() const;

  //! Get the maximum window size that fits on the usable display area
  window_size get_max_window_size() const;

  //! Get the display scale reported by the windowing system for the current
  //! window
  float get_display_scale() const;

  //! Enable optimisations for non-overlapping draws
  void start_nonoverlapping_draws();

  //! Disable optimisations for non-overlapping draws
  void finish_nonoverlapping_draws();

  //! Set the cursor to be used
  void set_cursor(cursor* pCursor);

  //! Update the cursor position (if the cursor is being simulated)
  void set_cursor_position(int iX, int iY);

  //! Take a screenshot and save it as a PNG file.
  bool take_screenshot(const char* file_path) const;

  //! Set the amount by which future draw operations are scaled.
  /*!
      @param fScale New scale to use.
      @param eWhatToScale Th kind of items to scale.
      @return Whether the scale could be set.
   */
  bool set_scale_factor(double fScale, scaled_items eWhatToScale);

  //! Set the window caption
  void set_caption(const char* sCaption);

  //! Toggle mouse capture on the window.
  void set_window_grab(bool bActivate);

  //! Get any user-displayable information to describe the renderer path used
  const char* get_renderer_details() const;

  // If you add any extra methods here which are called from outside the
  // rendering engine, then be sure to at least add dummy implementations
  // to the other rendering engines.

 public:  // Internal (this rendering engine only) API
  class scoped_buffer {
   public:
    virtual ~scoped_buffer() = default;
  };

  class scoped_target_texture final : public scoped_buffer {
   public:
    scoped_target_texture(render_target* pTarget, float iX, float iY,
                          int iWidth, int iHeight, bool bScale);
    scoped_target_texture(scoped_target_texture&) = delete;
    scoped_target_texture& operator=(scoped_target_texture&) = delete;
    ~scoped_target_texture() override;
    void offset(SDL_FRect& targetRect) const;
    double scale_factor() const;
    bool is_target() const;

   private:
    render_target* target;
    scoped_target_texture* previous_target;
    SDL_FRect rect;
    bool scale;
    SDL_Texture* texture{nullptr};
  };

  SDL_Renderer* get_renderer() const { return renderer; }

  SDL_Window* get_window() const { return window; }

  //! Should bitmaps be scaled?
  /*!
      @param [out] pFactor If the function returns \c true, the factor to use
          for scaling (can be \c nullptr if not interested in the value).
      @return Whether bitmaps should be scaled.
   */
  bool should_scale_bitmaps(double* pFactor);

  SDL_Texture* create_palettized_texture(int iWidth, int iHeight,
                                         const uint8_t* pPixels,
                                         const ::palette* pPalette,
                                         uint32_t iSpriteFlags) const;
  SDL_Texture* create_texture(int iWidth, int iHeight, const uint32_t* pPixels,
                              uint32_t sprite_flags) const;
  void draw(SDL_Texture* pTexture, const SDL_Rect* prcSrcRect,
            const SDL_FRect* prcDstRect, int iFlags);
  void draw_line(line_sequence* pLine, float iX, float iY);

  //! Begin drawing to an intermediate unscaled texture targeting the given
  //! location and size. The intermediate drawing will be committed once
  //! the returned scoped_buffer is destroyed.
  /*!
      @param iX X-coordinate of left side of drawing rectangle.
      @param iY Y-coordinate of top side of drawing rectangle.
      @param iWidth Width of drawing rectangle.
      @param iHeight Height of drawing rectangle.
   */
  std::unique_ptr<scoped_buffer> begin_intermediate_drawing(int iX, int iY,
                                                            int iWidth,
                                                            int iHeight);

 private:
  friend class scoped_target_texture;

  double draw_scale() const;

  void destroy_intermediate_textures();

  SDL_Window* window{nullptr};
  SDL_Renderer* renderer{nullptr};
  scoped_target_texture* current_target{nullptr};
  std::unique_ptr<scoped_target_texture> zoom_buffer;
  const SDL_PixelFormatDetails* pixel_format{nullptr};
  bool blue_filter_active{false};
  cursor* game_cursor{nullptr};
  double bitmap_scale_factor{1.0};  ///< Bitmap scale factor.
  double global_scale_factor{1.0};  ///< Global scale factor.
  int cursor_x{};
  int cursor_y{};

  std::stack<SDL_Rect> clip_rects;  ///< Stack of requested clip rects.

  // Intermediate textures used in the production of the current frame.
  // These are destroyed after the frame is presented.
  std::vector<SDL_Texture*> intermediate_textures;

  bool scale_bitmaps{false};  ///< Whether bitmaps should be scaled.
  bool supports_target_textures{};
  bool direct_zoom{};
  bool aspect_ratio_4_3{};
};

//! Stored image.
class raw_bitmap {
 public:
  raw_bitmap() = default;
  ~raw_bitmap();

  //! Set the palette of the image.
  /*!
      @param pPalette Palette to set for this image.
  */
  void set_palette(const ::palette* pPalette);

  //! Load the image from the supplied pixel data.
  /*!
      Loader uses the palette supplied before.
      @param pPixelData Image data loaded from a TH file.
      @param iPixelDataLength Size of the loaded image data.
      @param iWidth Width of the image.
      @param pEventualCanvas Canvas to render the image to (eventually).
      @param spriteFlags
      @return Loading was a success.
  */
  void load_from_th_file(const uint8_t* pPixelData, size_t iPixelDataLength,
                         int iWidth, render_target* pEventualCanvas,
                         uint32_t spriteFlags);

  //! Draw the image at a given position at the given canvas.
  /*!
      @param pCanvas Canvas to draw at.
      @param iX Destination x position.
      @param iY Destination y position.
  */
  void draw(render_target* pCanvas, float iX, float iY);

  //! Draw part of the image at a given position at the given canvas.
  /*!
      @param pCanvas Canvas to draw at.
      @param iX Destination x position.
      @param iY Destination y position.
      @param iSrcX X position of the part to display.
      @param iSrcY Y position of the part to display.
      @param iWidth Width of the part to display.
      @param iHeight Height of the part to display.
  */
  void draw(render_target* pCanvas, float iX, float iY, int iSrcX, int iSrcY,
            int iWidth, int iHeight);

 private:
  //! Image stored in SDL format for quick rendering.
  SDL_Texture* texture{nullptr};

  //! Palette of the image.
  const ::palette* bitmap_palette{nullptr};

  //! Target canvas.
  render_target* target{nullptr};

  //! Width of the stored image.
  int width{};

  //! Height of the stored image.
  int height{};
};

//! Sheet of sprites.
class sprite_sheet {
 public:  // External API
  sprite_sheet() = default;
  ~sprite_sheet();

  //! Set the palette to use for the sprites in the sheet.
  /*!
      @param pPalette Palette to use for the sprites at the sheet.
  */
  void set_palette(const ::palette* pPalette);

  //! Load the sprites from the supplied data (using the palette supplied
  //! earlier).
  /*!
      @param pTableData Start of table data with TH sprite information (see
     th_sprite_properties).
      @param iTableDataLength Length of the table data.
      @param pChunkData Start of image data (chunks).
      @param iChunkDataLength Length of the chunk data.
      @param bComplexChunks Whether the supplied chunks are 'complex'.
      @param pEventualCanvas Canvas to draw at.
      @return Loading succeeded.
  */
  bool load_from_th_file(const uint8_t* pTableData, size_t iTableDataLength,
                         const uint8_t* pChunkData, size_t iChunkDataLength,
                         bool bComplexChunks, render_target* pEventualCanvas);

  //! Set the data of a sprite.
  /*!
      @param iSprite Number of the sprite to set.
      @param pData Data of the sprite.
      @param bTakeData Whether the data block may be taken (must be new[]
     then).
      @param iDataLength Length of the data.
      @param iWidth Width of the sprite.
      @param iHeight Height of the sprite.
      @return Setting the sprite succeeded.
  */
  bool set_sprite_data(size_t iSprite, const uint8_t* pData, bool bTakeData,
                       size_t iDataLength, int iWidth, int iHeight);

  //! Supply a new mapped palette to a sprite.
  /*!
      @param iSprite Sprite getting the mapped palette.
      @param pMap The palette map to apply.
      @param iAlt32 What to do for a 32bpp sprite (#thdf_alt32_mask bits).
  */
  void set_sprite_alt_palette_map(size_t iSprite, const uint8_t* pMap,
                                  uint32_t iAlt32);

  //! Get the number of sprites at the sheet.
  /*!
      @return The number of sprites available at the sheet.
  */
  size_t get_sprite_count() const;

  //! Set the number of sprites in the sheet.
  /*!
      @param iCount The desired number of sprites.
      @param pCanvas Canvas to draw at.
      @return Whether the number of sprites could be allocated.
  */
  bool set_sprite_count(size_t iCount, render_target* pCanvas);

  //! Get size of a sprite.
  /*!
      @param iSprite Sprite to get info from.
      @param pWidth [out] If not nullptr, the sprite width is stored in the
     destination.
      @param pHeight [out] If not nullptr, the sprite height is stored in the
     destination.
      @return Size could be provided for the sprite.
  */
  bool get_sprite_size(size_t iSprite, int* pWidth, int* pHeight) const;

  //! Get size of a sprite, assuming all input is correctly supplied.
  /*!
      @param iSprite Sprite to get info from.
      @param pWidth [out] The sprite width is stored in the destination.
      @param pHeight [out] The sprite height is stored in the destination.
  */
  void get_sprite_size_unchecked(size_t iSprite, int* pWidth,
                                 int* pHeight) const;

  //! Get the best colour to represent the sprite.
  /*!
      @param iSprite Sprite number to analyze.
      @param pColour [out] Resulting colour.
      @return Best colour could be established.
  */
  bool get_sprite_average_colour(size_t iSprite, argb_colour* pColour) const;

  //! Return whether the given sprite show any pixel when displayed.
  /*!
      @param iSprite Sprite number to analyze.
      @return Whether any pixel of the sprite is visible.
  */
  bool is_sprite_visible(size_t iSprite) const;

  //! Draw a sprite onto the canvas.
  /*!
      @param pCanvas Canvas to draw on.
      @param iSprite Sprite to draw.
      @param iX X position to draw the sprite.
      @param iY Y position to draw the sprite.
      @param iFlags Flags to apply for drawing.
      @param effect_ticks The number of ticks into the effect animation.
      @param effect The animation effect to apply to the sprite.
      @param scale_factor How much to scale the sprite when drawing.
  */
  void draw_sprite(render_target* pCanvas, size_t iSprite, float iX, float iY,
                   uint32_t iFlags, size_t effect_ticks = 0u,
                   animation_effect effect = animation_effect::none,
                   int scale_factor = 1);

  //! Test whether a sprite was hit.
  /*!
      @param iSprite Sprite being tested.
      @param iX X position of the point to test relative to the origin of the
     sprite.
      @param iY Y position of the point to test relative to the origin of the
     sprite.
      @param iFlags Draw flags to apply to the sprite before testing.
      @return Whether the sprite covers the give point.
  */
  bool hit_test_sprite(size_t iSprite, int iX, int iY, uint32_t iFlags) const;

 public:  // Internal (this rendering engine only) API
  //! Draw a sprite into wxImage data arrays (for the Map Editor)
  /*!
      @param iSprite Sprite number to draw.
      @param pRGBData Output RGB data array.
      @param pAData Output Alpha channel array.
  */
  void wx_draw_sprite(size_t iSprite, uint8_t* pRGBData, uint8_t* pAData);

 private:
  friend class cursor;

  //! Sprites of the sheet.
  struct sprite {
    //! SDL structure containing the sprite with original palette.
    SDL_Texture* texture;

    //! SDL structure containing the sprite with alternative palette.
    SDL_Texture* alt_texture;

    //! Data of the sprite.
    const uint8_t* data;

    //! Alternative palette (if available).
    const uint8_t* alt_palette_map;

    //! Flags how to render the sprite, contains #THDF_Alt32_Mask bits.
    uint32_t sprite_flags;

    //! Width of the sprite.
    int width;

    //! Height of the sprite.
    int height;
  }* sprites{nullptr};

  //! Original palette.
  const ::palette* palette{nullptr};

  //! Target to render to.
  render_target* target{nullptr};

  //! Number of sprites in the sprite sheet.
  size_t sprite_count{};

  //! Free memory of a single sprite.
  /*!
      @param iNumber Number of the sprite to clear.
  */
  void _freeSingleSprite(size_t iNumber);

  //! Free the memory used by the sprites. Also releases the SDL bitmaps.
  void _freeSprites();

  //! Construct an alternative version (with its alternative palette map) of
  //! the sprite.
  /*!
      @param pSprite Sprite to change.
      @return SDL texture containing the sprite.
  */
  SDL_Texture* _makeAltBitmap(sprite* pSprite);
};

class cursor {
 public:
  cursor() = default;
  ~cursor();

  bool create_from_sprite(sprite_sheet* pSheet, size_t iSprite,
                          int iHotspotX = 0, int iHotspotY = 0);

  void use(render_target* pTarget);

  static bool set_position(render_target* pTarget, float iX, float iY);

  void draw(render_target* pCanvas, int iX, int iY);

 private:
  SDL_Surface* bitmap{nullptr};
  SDL_Cursor* hidden_cursor{nullptr};
  int hotspot_x{};
  int hotspot_y{};
};

class line_sequence {
 public:
  line_sequence();

  void move_to(double fX, double fY);

  void line_to(double fX, double fY);

  void set_width(double lineWidth);

  void draw(render_target* pCanvas, float iX, float iY);

  void set_colour(uint8_t iR, uint8_t iG, uint8_t iB, uint8_t iA = 255);

  void persist(lua_persist_writer* pWriter) const;
  void depersist(lua_persist_reader* pReader);

 private:
  friend class render_target;

  enum class line_command : uint32_t { move = 0, line = 1 };

  class line_element {
   public:
    line_command type;
    double x, y;
    line_element(line_command type, double x, double y)
        : type(type), x(x), y(y) {}
  };

  std::vector<line_element> line_elements;
  double width{1};
  uint8_t red{0}, green{0}, blue{0}, alpha{255};
};

#endif  // CORSIX_TH_TH_GFX_SDL_H_
